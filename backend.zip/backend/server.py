"""
Real-Time Crypto Data Pipeline — Backend Server
- WebSocket server for live price streaming
- REST endpoints for historical data
- Simulates ingestion from CoinGecko / Binance APIs
- In production: replace mock data with real API calls
"""

import asyncio
import json
import random
import time
import math
from datetime import datetime, timedelta
from typing import Set
import websockets
import aiohttp
from aiohttp import web
import aiohttp_cors

# ─── CONFIG ──────────────────────────────────────────────────────────────────
PORT_WS   = 8765
PORT_HTTP = 8080

COINS = {
    "BTC": {"name": "Bitcoin",   "base": 67000, "vol": 1200},
    "ETH": {"name": "Ethereum",  "base": 3400,  "vol": 80},
    "SOL": {"name": "Solana",    "base": 185,   "vol": 6},
    "BNB": {"name": "BNB",       "base": 580,   "vol": 12},
    "XRP": {"name": "XRP",       "base": 0.62,  "vol": 0.02},
    "ADA": {"name": "Cardano",   "base": 0.48,  "vol": 0.015},
}

# In-memory price state
price_state = {
    symbol: {
        "price": info["base"],
        "change_24h": round(random.uniform(-5, 5), 2),
        "volume_24h": round(random.uniform(1e9, 50e9), 0),
        "market_cap": round(info["base"] * random.uniform(1e7, 1e9), 0),
        "history": [],          # last 60 ticks
    }
    for symbol, info in COINS.items()
}

# Pre-fill history with synthetic OHLCV data (last 24h, 1h candles)
def _generate_history(symbol: str):
    info = COINS[symbol]
    base = info["base"]
    candles = []
    now = datetime.utcnow()
    price = base * random.uniform(0.92, 1.08)
    for i in range(24, -1, -1):
        t = now - timedelta(hours=i)
        o = price
        h = o * random.uniform(1.000, 1.012)
        l = o * random.uniform(0.988, 1.000)
        c = random.uniform(l, h)
        v = round(random.uniform(info["vol"] * 0.5, info["vol"] * 2) * 1e6, 0)
        candles.append({
            "t": t.isoformat(),
            "o": round(o, 4),
            "h": round(h, 4),
            "l": round(l, 4),
            "c": round(c, 4),
            "v": v,
        })
        price = c
    return candles

for sym in price_state:
    price_state[sym]["history"] = _generate_history(sym)

# ─── PRICE SIMULATION (replaces real API ingestion) ───────────────────────────
def tick_prices():
    """Simulate streaming price updates. In production: consume from Kafka/Kinesis."""
    for symbol, info in COINS.items():
        state = price_state[symbol]
        drift   = math.sin(time.time() / 300) * 0.001       # slow trend
        noise   = random.gauss(0, info["vol"] * 0.0003)     # market noise
        shock   = random.gauss(0, info["vol"] * 0.0001)     # occasional spike
        delta   = state["price"] * (drift + noise + shock)
        state["price"] = round(max(state["price"] + delta, info["base"] * 0.5), 6)

        # Update rolling 24h change
        if state["history"]:
            open_24h = state["history"][0]["o"]
            state["change_24h"] = round((state["price"] - open_24h) / open_24h * 100, 2)

        # Append live tick to history
        now = datetime.utcnow().isoformat()
        state["history"].append({
            "t": now,
            "o": state["price"],
            "h": state["price"] * random.uniform(1.0, 1.003),
            "l": state["price"] * random.uniform(0.997, 1.0),
            "c": state["price"],
            "v": round(random.uniform(COINS[symbol]["vol"] * 0.3, COINS[symbol]["vol"]) * 1e5, 0),
        })
        if len(state["history"]) > 200:
            state["history"].pop(0)

def build_snapshot():
    return {
        "type": "snapshot",
        "ts": datetime.utcnow().isoformat(),
        "data": {
            symbol: {
                "symbol":      symbol,
                "name":        COINS[symbol]["name"],
                "price":       state["price"],
                "change_24h":  state["change_24h"],
                "volume_24h":  state["volume_24h"],
                "market_cap":  state["market_cap"],
            }
            for symbol, state in price_state.items()
        }
    }

# ─── WEBSOCKET SERVER ─────────────────────────────────────────────────────────
connected_clients: Set[websockets.WebSocketServerProtocol] = set()

async def ws_handler(websocket, path="/"):
    connected_clients.add(websocket)
    print(f"[WS] Client connected. Total: {len(connected_clients)}")
    try:
        # Send initial snapshot
        await websocket.send(json.dumps(build_snapshot()))
        async for message in websocket:
            pass  # client messages ignored for now
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        connected_clients.discard(websocket)
        print(f"[WS] Client disconnected. Total: {len(connected_clients)}")

async def broadcast_loop():
    """Broadcast price ticks to all connected WS clients every second."""
    while True:
        await asyncio.sleep(1)
        tick_prices()
        if connected_clients:
            snapshot = json.dumps(build_snapshot())
            await asyncio.gather(
                *[c.send(snapshot) for c in list(connected_clients)],
                return_exceptions=True
            )

# ─── HTTP REST API ────────────────────────────────────────────────────────────
async def handle_coins(request):
    data = {
        symbol: {
            "symbol":     symbol,
            "name":       COINS[symbol]["name"],
            "price":      state["price"],
            "change_24h": state["change_24h"],
            "volume_24h": state["volume_24h"],
            "market_cap": state["market_cap"],
        }
        for symbol, state in price_state.items()
    }
    return web.json_response({"data": data, "ts": datetime.utcnow().isoformat()})

async def handle_history(request):
    symbol = request.match_info.get("symbol", "").upper()
    if symbol not in price_state:
        return web.json_response({"error": "Unknown symbol"}, status=404)
    return web.json_response({
        "symbol":  symbol,
        "history": price_state[symbol]["history"],
        "ts":      datetime.utcnow().isoformat()
    })

async def handle_health(request):
    return web.json_response({"status": "ok", "clients": len(connected_clients)})

def create_http_app():
    app = web.Application()
    cors = aiohttp_cors.setup(app, defaults={
        "*": aiohttp_cors.ResourceOptions(allow_credentials=True, expose_headers="*", allow_headers="*")
    })
    r1 = app.router.add_get("/api/coins",            handle_coins)
    r2 = app.router.add_get("/api/coins/{symbol}",   handle_history)
    r3 = app.router.add_get("/health",               handle_health)
    for r in [r1, r2, r3]:
        cors.add(r)
    return app

# ─── ENTRYPOINT ───────────────────────────────────────────────────────────────
async def main():
    print(f"🚀  WebSocket server  → ws://localhost:{PORT_WS}")
    print(f"🌐  HTTP REST API     → http://localhost:{PORT_HTTP}")

    ws_server  = websockets.serve(ws_handler, "0.0.0.0", PORT_WS)
    http_app   = create_http_app()
    runner     = web.AppRunner(http_app)

    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", PORT_HTTP)

    await asyncio.gather(ws_server, site.start(), broadcast_loop())

if __name__ == "__main__":
    asyncio.run(main())
