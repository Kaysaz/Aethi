import { useEffect, useRef, useState, useCallback } from 'react'

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8765'

export function useLivePrices() {
  const [prices, setPrices]         = useState({})
  const [prevPrices, setPrevPrices] = useState({})
  const [status, setStatus]         = useState('connecting') // connecting | live | error
  const [lastUpdate, setLastUpdate] = useState(null)
  const [tickCount, setTickCount]   = useState(0)
  const wsRef                       = useRef(null)
  const reconnectTimer              = useRef(null)

  const connect = useCallback(() => {
    try {
      const ws = new WebSocket(WS_URL)
      wsRef.current = ws

      ws.onopen = () => {
        setStatus('live')
        console.log('[WS] connected')
      }

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data)
          if (msg.type === 'snapshot') {
            setPrevPrices(prev => ({ ...prev }))
            setPrices(old => {
              const next = { ...old }
              Object.entries(msg.data).forEach(([sym, d]) => {
                next[sym] = { ...d, prevPrice: old[sym]?.price }
              })
              return next
            })
            setLastUpdate(new Date(msg.ts))
            setTickCount(c => c + 1)
          }
        } catch (e) {
          console.error('[WS] parse error', e)
        }
      }

      ws.onerror = () => setStatus('error')

      ws.onclose = () => {
        setStatus('connecting')
        reconnectTimer.current = setTimeout(connect, 3000)
      }
    } catch {
      setStatus('error')
      reconnectTimer.current = setTimeout(connect, 5000)
    }
  }, [])

  useEffect(() => {
    connect()
    return () => {
      clearTimeout(reconnectTimer.current)
      wsRef.current?.close()
    }
  }, [connect])

  return { prices, status, lastUpdate, tickCount }
}
