import { useEffect, useState } from 'react'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8080'

export function useCoinHistory(symbol) {
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!symbol) return
    setLoading(true)
    fetch(`${API_BASE}/api/coins/${symbol}`)
      .then(r => r.json())
      .then(d => {
        setHistory(d.history || [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [symbol])

  return { history, loading }
}
