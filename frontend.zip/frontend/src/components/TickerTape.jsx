import React from 'react'
import { fmt } from '../lib/format'

export function TickerTape({ prices }) {
  const coins = Object.values(prices)
  if (!coins.length) return null
  const items = [...coins, ...coins] // duplicate for seamless loop

  return (
    <div style={{ background: 'var(--bg-card)', borderBottom: '1px solid var(--border)', overflow: 'hidden', height: 32 }}
      className="flex items-center">
      <div className="ticker-track flex items-center gap-0" style={{ whiteSpace: 'nowrap' }}>
        {items.map((c, i) => {
          const up = c.change_24h >= 0
          return (
            <span key={i} style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', padding: '0 24px',
              borderRight: '1px solid var(--border)', display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              <span style={{ color: 'var(--text-muted)', letterSpacing: '0.08em' }}>{c.symbol}</span>
              <span style={{ color: 'var(--text-primary)' }}>${fmt(c.price, c.price < 1 ? 4 : 2)}</span>
              <span style={{ color: up ? 'var(--green)' : 'var(--red)', fontSize: '0.65rem' }}>
                {up ? '▲' : '▼'} {Math.abs(c.change_24h).toFixed(2)}%
              </span>
            </span>
          )
        })}
      </div>
    </div>
  )
}
