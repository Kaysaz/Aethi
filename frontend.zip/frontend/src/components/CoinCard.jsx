import React, { useEffect, useRef, useState } from 'react'
import { fmt, fmtLarge } from '../lib/format'

export function CoinCard({ coin, selected, onClick }) {
  const cardRef  = useRef(null)
  const prevRef  = useRef(coin?.price)
  const [flash, setFlash] = useState(null)

  useEffect(() => {
    if (!coin) return
    const prev = prevRef.current
    if (prev != null && prev !== coin.price) {
      const dir = coin.price > prev ? 'green' : 'red'
      setFlash(dir)
      const t = setTimeout(() => setFlash(null), 600)
      prevRef.current = coin.price
      return () => clearTimeout(t)
    }
    prevRef.current = coin.price
  }, [coin?.price])

  if (!coin) return null
  const up = coin.change_24h >= 0
  const isSmall = coin.price < 1

  return (
    <div ref={cardRef}
      onClick={onClick}
      className={flash === 'green' ? 'flash-green' : flash === 'red' ? 'flash-red' : ''}
      style={{
        background: selected ? 'var(--bg-elevated)' : 'var(--bg-card)',
        border: selected ? '1px solid var(--accent)' : '1px solid var(--border)',
        borderRadius: 8,
        padding: '16px 20px',
        cursor: 'pointer',
        transition: 'border-color 0.2s, background 0.2s',
        boxShadow: selected ? '0 0 20px var(--accent-dim)' : 'none',
        position: 'relative',
        overflow: 'hidden',
      }}>
      {selected && (
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2,
          background: 'linear-gradient(90deg, transparent, var(--accent), transparent)' }} />
      )}

      {/* Top row */}
      <div className="flex items-center justify-between mb-3">
        <div>
          <div style={{ fontWeight: 700, fontSize: '0.95rem', letterSpacing: '-0.01em' }}>{coin.symbol}</div>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: 2 }}>{coin.name}</div>
        </div>
        <div style={{
          padding: '3px 8px', borderRadius: 4, fontSize: '0.72rem', fontFamily: 'var(--font-mono)',
          background: up ? 'rgba(0,255,148,0.1)' : 'rgba(255,61,113,0.1)',
          color: up ? 'var(--green)' : 'var(--red)',
          border: `1px solid ${up ? 'rgba(0,255,148,0.2)' : 'rgba(255,61,113,0.2)'}`,
        }}>
          {up ? '+' : ''}{coin.change_24h.toFixed(2)}%
        </div>
      </div>

      {/* Price */}
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.25rem', fontWeight: 700,
        color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
        ${fmt(coin.price, isSmall ? 4 : 2)}
      </div>

      {/* Volume & MCap */}
      <div className="flex justify-between mt-3">
        <div>
          <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)', letterSpacing: '0.08em', marginBottom: 2 }}>VOL 24H</div>
          <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-mid)' }}>
            {fmtLarge(coin.volume_24h)}
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)', letterSpacing: '0.08em', marginBottom: 2 }}>MKT CAP</div>
          <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-mid)' }}>
            {fmtLarge(coin.market_cap)}
          </div>
        </div>
      </div>

      {/* Live tick indicator */}
      <div style={{ position: 'absolute', bottom: 8, right: 10, display: 'flex', alignItems: 'center', gap: 4 }}>
        <div className="pulse-dot" style={{ width: 5, height: 5, borderRadius: '50%',
          background: 'var(--accent)', boxShadow: '0 0 6px var(--accent)' }} />
        <span style={{ fontSize: '0.55rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>LIVE</span>
      </div>
    </div>
  )
}
