import React, { useMemo } from 'react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine
} from 'recharts'
import { useCoinHistory } from '../hooks/useHistory'
import { fmt } from '../lib/format'

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  const d = payload[0]?.payload
  if (!d) return null
  const up = d.c >= d.o
  return (
    <div style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border)',
      borderRadius: 6, padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: '0.72rem' }}>
      <div style={{ color: 'var(--text-muted)', marginBottom: 6 }}>{new Date(d.t).toLocaleString()}</div>
      <div className="grid grid-cols-2 gap-x-6 gap-y-1">
        {[['O', d.o], ['H', d.h], ['L', d.l], ['C', d.c]].map(([k, v]) => (
          <div key={k} className="flex justify-between gap-3">
            <span style={{ color: 'var(--text-muted)' }}>{k}</span>
            <span style={{ color: k === 'C' ? (up ? 'var(--green)' : 'var(--red)') : 'var(--text-primary)' }}>
              ${fmt(v, v < 1 ? 4 : 2)}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

export function PriceChart({ symbol, livePrice }) {
  const { history, loading } = useCoinHistory(symbol)

  const data = useMemo(() => {
    if (!history.length) return []
    return history.map(h => ({ ...h, mid: (h.h + h.l) / 2 }))
  }, [history])

  const isUp = data.length >= 2 ? data[data.length - 1].c >= data[0].o : true
  const color = isUp ? 'var(--green)' : 'var(--red)'
  const colorHex = isUp ? '#00ff94' : '#ff3d71'

  if (loading) {
    return (
      <div style={{ height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>
        LOADING HISTORY...
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em' }}>
            24H PRICE CHART — {symbol}
          </span>
        </div>
        <div style={{ display: 'flex', gap: 16, fontFamily: 'var(--font-mono)', fontSize: '0.65rem' }}>
          {['1H', '4H', '24H'].map(t => (
            <button key={t} style={{ color: t === '24H' ? 'var(--accent)' : 'var(--text-muted)',
              background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={280}>
        <AreaChart data={data} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor={colorHex} stopOpacity={0.25} />
              <stop offset="95%" stopColor={colorHex} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
          <XAxis dataKey="t"
            tickFormatter={v => new Date(v).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })}
            tick={{ fill: '#4a6080', fontSize: 10, fontFamily: 'Space Mono' }}
            tickLine={false} axisLine={false} interval={3} />
          <YAxis
            tickFormatter={v => `$${fmt(v, v < 1 ? 3 : 0)}`}
            tick={{ fill: '#4a6080', fontSize: 10, fontFamily: 'Space Mono' }}
            tickLine={false} axisLine={false} domain={['auto', 'auto']} width={80} />
          <Tooltip content={<CustomTooltip />} />
          {livePrice && (
            <ReferenceLine y={livePrice} stroke={colorHex} strokeDasharray="4 4" strokeWidth={1}
              label={{ value: `$${fmt(livePrice, 2)}`, fill: colorHex, fontSize: 10, fontFamily: 'Space Mono', position: 'right' }} />
          )}
          <Area type="monotone" dataKey="c" stroke={colorHex} strokeWidth={1.5}
            fill="url(#priceGrad)" dot={false} activeDot={{ r: 4, fill: colorHex, stroke: '#050810', strokeWidth: 2 }} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
