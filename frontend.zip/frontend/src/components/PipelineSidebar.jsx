import React from 'react'
import { Database, Cpu, Cloud, BarChart2, Zap } from 'lucide-react'

const STAGES = [
  {
    icon: <Zap size={14} />,
    label: 'DATA INGESTION',
    detail: 'CoinGecko API / Binance WS',
    sub: 'REST polling + WebSocket feed',
    color: '#a78bfa',
  },
  {
    icon: <Cpu size={14} />,
    label: 'PROCESSING',
    detail: 'Python asyncio / aiohttp',
    sub: 'Price calc, delta, aggregation',
    color: '#00e5ff',
  },
  {
    icon: <Cloud size={14} />,
    label: 'CLOUD LAYER',
    detail: 'AWS / GCP compatible',
    sub: 'Docker → ECS / Cloud Run',
    color: '#60a5fa',
  },
  {
    icon: <Database size={14} />,
    label: 'STORAGE',
    detail: 'TimescaleDB / BigQuery',
    sub: 'Time-series OHLCV warehouse',
    color: '#34d399',
  },
  {
    icon: <BarChart2 size={14} />,
    label: 'VISUALISATION',
    detail: 'React + Recharts',
    sub: 'WebSocket push, live render',
    color: '#fbbf24',
  },
]

export function PipelineSidebar({ tickCount, status }) {
  return (
    <aside style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 8, padding: 20 }}>
      <div style={{ fontSize: '0.65rem', letterSpacing: '0.12em', color: 'var(--text-muted)',
        fontFamily: 'var(--font-mono)', marginBottom: 16 }}>
        PIPELINE ARCHITECTURE
      </div>

      <div className="flex flex-col gap-0">
        {STAGES.map((s, i) => (
          <div key={i}>
            <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              {/* Connector line */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 2 }}>
                <div style={{ color: s.color, background: `${s.color}20`, border: `1px solid ${s.color}40`,
                  borderRadius: 4, padding: 5, display: 'flex' }}>
                  {s.icon}
                </div>
                {i < STAGES.length - 1 && (
                  <div style={{ width: 1, flexGrow: 1, minHeight: 20, background: 'var(--border)', margin: '3px 0' }} />
                )}
              </div>
              {/* Text */}
              <div style={{ paddingBottom: 16 }}>
                <div style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '0.05em' }}>{s.label}</div>
                <div style={{ fontSize: '0.68rem', color: s.color, fontFamily: 'var(--font-mono)', marginTop: 1 }}>{s.detail}</div>
                <div style={{ fontSize: '0.63rem', color: 'var(--text-muted)', marginTop: 2 }}>{s.sub}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Stats */}
      <div style={{ borderTop: '1px solid var(--border)', marginTop: 4, paddingTop: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {[
          { label: 'TICKS RECV', value: tickCount.toLocaleString() },
          { label: 'LATENCY', value: status === 'live' ? '~1s' : '—' },
          { label: 'PROTOCOL', value: 'WS/JSON' },
          { label: 'FREQ', value: '1 Hz' },
          { label: 'COINS', value: '6' },
          { label: 'STATUS', value: status.toUpperCase() },
        ].map((m, i) => (
          <div key={i}>
            <div style={{ fontSize: '0.55rem', color: 'var(--text-muted)', letterSpacing: '0.1em', marginBottom: 2 }}>{m.label}</div>
            <div style={{ fontSize: '0.78rem', fontFamily: 'var(--font-mono)',
              color: m.label === 'STATUS' ? (status === 'live' ? 'var(--green)' : 'var(--amber)') : 'var(--accent)' }}>
              {m.value}
            </div>
          </div>
        ))}
      </div>
    </aside>
  )
}
