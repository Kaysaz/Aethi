import React from 'react'
import { Activity, Wifi, WifiOff, Loader } from 'lucide-react'
import { fmtTime } from '../lib/format'

export function Header({ status, lastUpdate, tickCount }) {
  return (
    <header style={{ borderBottom: '1px solid var(--border)', background: 'var(--bg-card)' }}
      className="px-6 py-4 flex items-center justify-between sticky top-0 z-50">

      {/* Logo */}
      <div className="flex items-center gap-3">
        <div style={{ color: 'var(--accent)', background: 'var(--accent-dim)', border: '1px solid var(--accent-glow)' }}
          className="p-2 rounded">
          <Activity size={20} />
        </div>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.1rem', letterSpacing: '-0.02em', color: 'var(--text-primary)' }}>
            DATA<span style={{ color: 'var(--accent)' }}>STREAM</span>
          </h1>
          <p style={{ fontSize: '0.65rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}>
            REAL-TIME PIPELINE DASHBOARD
          </p>
        </div>
      </div>

      {/* Pipeline status strip */}
      <div className="flex items-center gap-6">
        <PipelineStage label="INGEST"   active={status === 'live'} />
        <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>→</div>
        <PipelineStage label="PROCESS"  active={status === 'live'} delay={200} />
        <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>→</div>
        <PipelineStage label="STREAM"   active={status === 'live'} delay={400} />
        <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>→</div>
        <PipelineStage label="DISPLAY"  active={status === 'live'} delay={600} />
      </div>

      {/* Connection status */}
      <div className="flex items-center gap-4">
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
          <span style={{ color: 'var(--accent)' }}>{tickCount.toLocaleString()}</span> ticks
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
          {fmtTime(lastUpdate) || '--:--:--'}
        </div>
        <StatusBadge status={status} />
      </div>
    </header>
  )
}

function PipelineStage({ label, active, delay = 0 }) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="pulse-dot" style={{
        width: 6, height: 6, borderRadius: '50%',
        background: active ? 'var(--green)' : 'var(--text-muted)',
        animationDelay: `${delay}ms`,
        boxShadow: active ? '0 0 8px var(--green)' : 'none',
      }} />
      <span style={{ fontSize: '0.6rem', letterSpacing: '0.1em', fontFamily: 'var(--font-mono)', color: active ? 'var(--text-mid)' : 'var(--text-muted)' }}>
        {label}
      </span>
    </div>
  )
}

function StatusBadge({ status }) {
  const cfg = {
    live:        { icon: <Wifi size={13} />,    label: 'LIVE',         color: 'var(--green)', bg: 'rgba(0,255,148,0.1)' },
    connecting:  { icon: <Loader size={13} className="animate-spin" />, label: 'CONNECTING', color: 'var(--amber)', bg: 'rgba(255,185,48,0.1)' },
    error:       { icon: <WifiOff size={13} />, label: 'DISCONNECTED', color: 'var(--red)',   bg: 'rgba(255,61,113,0.1)' },
  }[status] || {}

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 4,
      background: cfg.bg, border: `1px solid ${cfg.color}33`, color: cfg.color,
      fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.08em' }}>
      {cfg.icon}
      {cfg.label}
    </div>
  )
}
