import React, { useState } from 'react'
import { Header } from './components/Header'
import { TickerTape } from './components/TickerTape'
import { CoinCard } from './components/CoinCard'
import { PriceChart } from './components/PriceChart'
import { PipelineSidebar } from './components/PipelineSidebar'
import { useLivePrices } from './hooks/useLivePrices'
import { fmt, fmtLarge } from './lib/format'

export default function App() {
  const { prices, status, lastUpdate, tickCount } = useLivePrices()
  const [selected, setSelected] = useState('BTC')

  const coinList = Object.values(prices)
  const selectedCoin = prices[selected]

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header status={status} lastUpdate={lastUpdate} tickCount={tickCount} />
      <TickerTape prices={prices} />

      <main style={{ flex: 1, padding: '24px', maxWidth: 1600, margin: '0 auto', width: '100%' }}>

        {/* Page title */}
        <div style={{ marginBottom: 24 }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800, letterSpacing: '-0.03em', color: 'var(--text-primary)' }}>
            Live Crypto <span style={{ color: 'var(--accent)' }}>Pipeline</span>
          </h2>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 4, fontFamily: 'var(--font-mono)' }}>
            Real-time price ingestion → WebSocket stream → React visualisation
          </p>
        </div>

        {/* Coin cards grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 12, marginBottom: 24 }}>
          {coinList.length === 0
            ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
            : coinList.map(coin => (
              <CoinCard key={coin.symbol} coin={coin}
                selected={selected === coin.symbol}
                onClick={() => setSelected(coin.symbol)} />
            ))
          }
        </div>

        {/* Main chart + sidebar */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16, alignItems: 'start' }}>

          {/* Chart panel */}
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 8, padding: 24 }}>
            {selectedCoin ? (
              <>
                {/* Selected coin header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div>
                      <div style={{ fontSize: '1.8rem', fontWeight: 800, letterSpacing: '-0.04em',
                        fontFamily: 'var(--font-mono)', color: 'var(--text-primary)' }}>
                        ${fmt(selectedCoin.price, selectedCoin.price < 1 ? 4 : 2)}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4 }}>
                        <span style={{ fontSize: '0.9rem', fontWeight: 700 }}>{selectedCoin.name}</span>
                        <span style={{
                          padding: '2px 8px', borderRadius: 4, fontSize: '0.75rem', fontFamily: 'var(--font-mono)',
                          background: selectedCoin.change_24h >= 0 ? 'rgba(0,255,148,0.12)' : 'rgba(255,61,113,0.12)',
                          color: selectedCoin.change_24h >= 0 ? 'var(--green)' : 'var(--red)',
                        }}>
                          {selectedCoin.change_24h >= 0 ? '+' : ''}{selectedCoin.change_24h.toFixed(2)}%
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-8">
                    {[
                      { label: 'VOLUME 24H', value: fmtLarge(selectedCoin.volume_24h) },
                      { label: 'MKT CAP',    value: fmtLarge(selectedCoin.market_cap) },
                    ].map(s => (
                      <div key={s.label} style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)', letterSpacing: '0.1em', marginBottom: 4 }}>{s.label}</div>
                        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.9rem', color: 'var(--text-primary)' }}>{s.value}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <PriceChart symbol={selected} livePrice={selectedCoin.price} />
              </>
            ) : (
              <div style={{ height: 380, display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>
                AWAITING CONNECTION...
              </div>
            )}
          </div>

          {/* Sidebar */}
          <PipelineSidebar tickCount={tickCount} status={status} />
        </div>

        {/* Bottom market overview bar */}
        {coinList.length > 0 && (
          <div style={{ marginTop: 16, background: 'var(--bg-card)', border: '1px solid var(--border)',
            borderRadius: 8, padding: '14px 20px', display: 'flex', gap: 32, overflowX: 'auto' }}>
            <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)', letterSpacing: '0.1em',
              fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap', alignSelf: 'center' }}>
              MARKET OVERVIEW
            </div>
            {coinList.map(c => (
              <MiniStat key={c.symbol} coin={c} onClick={() => setSelected(c.symbol)} active={selected === c.symbol} />
            ))}
          </div>
        )}
      </main>

      <footer style={{ borderTop: '1px solid var(--border)', padding: '12px 24px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-muted)' }}>
          DATASTREAM PIPELINE DASHBOARD — DATA FOR DEMO PURPOSES ONLY
        </span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-muted)' }}>
          WS → PYTHON → REACT
        </span>
      </footer>
    </div>
  )
}

function MiniStat({ coin, onClick, active }) {
  const up = coin.change_24h >= 0
  return (
    <div onClick={onClick} style={{ cursor: 'pointer', textAlign: 'center', minWidth: 70 }}>
      <div style={{ fontSize: '0.65rem', fontWeight: 700, color: active ? 'var(--accent)' : 'var(--text-mid)' }}>{coin.symbol}</div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-primary)', marginTop: 2 }}>
        ${fmt(coin.price, coin.price < 1 ? 3 : 0)}
      </div>
      <div style={{ fontSize: '0.62rem', color: up ? 'var(--green)' : 'var(--red)', marginTop: 1 }}>
        {up ? '+' : ''}{coin.change_24h.toFixed(2)}%
      </div>
    </div>
  )
}

function SkeletonCard() {
  return (
    <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 8,
      padding: '16px 20px', height: 120 }}>
      <div style={{ background: 'var(--border)', borderRadius: 4, height: 12, width: '40%', marginBottom: 8,
        animation: 'pulse 1.5s ease-in-out infinite' }} />
      <div style={{ background: 'var(--border)', borderRadius: 4, height: 20, width: '70%', marginBottom: 12 }} />
      <div style={{ background: 'var(--border)', borderRadius: 4, height: 10, width: '55%' }} />
    </div>
  )
}
